# C99 WebShell with PHP7 and MySQL Support

PHP 7 and safe-build Update of the popular C99 variant of PHP Shell with MySQL support<br/>
(extension of [https://github.com/KaizenLouie/C99Shell-PHP7](https://github.com/KaizenLouie/C99Shell-PHP7)).

**Note:** Zip archive is encrypted to avoid antivirus detection when downloaded (**password:** c99shell).

<br/>

## Disclaimer

This repository was created for educational purposes only.
